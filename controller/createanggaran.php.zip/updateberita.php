<?php
/**
 * Created by PhpStorm.
 * User: Galih
 * Date: 9/20/2017
 * Time: 8:47 PM
 */
    require_once ('../lib/Dbcon.php');
    require_once ('../model/model.php');
        $period = new input();
            if (isset($_POST ['updateberita'])) {
                if (!empty($_POST)) {
					$idberita = $_POST['idberita'];
                    $judulberita = $_POST['judulberita'];
                    $isiberita = $_POST['isiberita'];
					$tipe = $_POST['tipe'];
                    $tglpublish = $_POST['tglpublish'];
                    $period->updateberita($idberita,$judulberita,$isiberita,$tipe,$tglpublish);
                    $success = "Data Berhasil di Tambahkan";

                }
            }
    header("location:../view/detailberita.php");
?>
