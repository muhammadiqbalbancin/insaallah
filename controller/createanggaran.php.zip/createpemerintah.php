<?php
/**
 * Created by PhpStorm.
 * User: Galih
 * Date: 1/8/2018
 * Time: 12:32 AM
 */
require_once ('../lib/Dbcon.php');
require_once ('../model/model.php');
$period = new input();
if (isset($_POST ['inputpemerintah'])) {
    if (!empty($_POST)) {
        $namapemerintah = $_POST['namapemerintah'];
        $nippemerintah = $_POST['nippemerintah'];
        $jabatanpemerintah= $_POST['jabatanpemerintah'];
                $period->createpemerintah($namapemerintah,$nippemerintah,$jabatanpemerintah);
        }
    } else {
        session_start();
        $error = '';

    }
header("location:../view/detailpemerintah.php");
?>