<?php
/**
 * Created by PhpStorm.
 * User: Galih
 * Date: 9/20/2017
 * Time: 4:42 PM
 */
$servername = 'ibanc-dev.com';
$username = 'u6015561_rantaugedanguser';
$password = 'rantaugedanguser';
$dbname = 'u6015561_rantaugedang';

$con = mysqli_connect($servername,$username,$password,$dbname);
if (!$con){
    die('connection failed :'.mysqli_error());
}
?>
