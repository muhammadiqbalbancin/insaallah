<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../asset/css/menu.css">
    <link rel="stylesheet" href="../asset/bootstrap/css/w3.css">
    <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../asset/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../asset/css/bantu1.css">
    <script src="../asset/js/bantu1.js"></script>
    <script src="../asset/bootstrap/js/bootstrap.min.js"></script>
    <title>Dashboard Administrator Rantau Gedang</title>
    <style media="screen">
    #div {
      width: 100%;
      height: 400px;
      background-image: url('download.jpg');
      background-size: 100% 100%;
      border: ;
    }
    td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 5px;
        color: black;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
    tr:hover th,
    tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
    </style>
</head>

<body>
<div>
      <h4 style="text-align: center;text-decoration: solid;"><b>Struktur Desa Rantau Gedang</b></h4>
    <div class="col col-sm-12 col-xs-12 col-md-12">
      <div class="" id="div">

      </div>
        <h4 style="text-align: center;text-decoration: solid;"><b>Pejabat Struktural Desa Rantau Gedang</b></h4>
        <table class="table-responsive" >
            <tr style="background-color:#508abb;">
                <th>Nama</th>
                <th>Jabatan</th>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;" >HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">CAMAT</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982045 044</td>
              <td style="font-size:10px;text-align:center">SKRETARIS KECAMATAN</td>
            </tr>
            <tr>
              <td width="45%"style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br> NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASUBAG PERENCANAAN</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASUBAG KEUNGAN & PROGRAM</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASI KESSOS</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASI PELAYANAN UMUM</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASI EKBANG</td>
            </tr>
            <tr>
              <td width="45%" style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
              <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASI KETENTRAMAN & KETERTIBAN</td>
            </tr>
            <tr>
              <td width="45%"style="font-size:10px;">HJ.SITI SAMARIA SIA, S.IP
               <br>NIP:19601113 1982032 099</td>
              <td style="font-size:10px;text-align:center">KASI PEMERINTAHAN</td>
            </tr>
        </table>
        <br><br>
        <p style="text-align: center">&copy; 2019</p>
    </div>
</div>
</body>
</html>
