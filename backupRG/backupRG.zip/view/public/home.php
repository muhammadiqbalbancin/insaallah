<?php
/**
 * Created by PhpStorm.
 * User: Galih
 * Date: 9/29/2017
 * Time: 7:48 AM
 */
?>
<!DOCTYPE html>
<html lang="en"
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" type="text/css" href="../../asset/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../../font-awesome/css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="../../asset/bootstrap/js/bootstrap.min.js">
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">

            </div>
            <div class="row">

            </div>
            <div class="row container">

            </div>
            <div class="row">

            </div>
        </div>
    </body>
</html>